__path__.append('/afs/cern.ch/cms/slc6_amd64_gcc491/cms/cmssw/CMSSW_7_4_15/python/PhysicsTools')
